import productRead

print productRead.getFarnellRequestUrl('keyword', 'gf')
