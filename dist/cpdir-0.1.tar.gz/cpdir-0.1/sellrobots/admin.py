from django.contrib import admin
from sellrobots.models import order

admin.site.register(order)
